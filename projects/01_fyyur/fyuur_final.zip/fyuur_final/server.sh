export FLASK_APP=app
export FLASK_ENV=development # enables debug mode
python3 app.py
